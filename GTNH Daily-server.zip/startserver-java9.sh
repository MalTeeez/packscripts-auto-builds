#!/bin/bash

# don't forget to accept the EULA or it won't boot
# add this argument behind the other "-Dfml..." to silently migrate your world during startup, a backup will be created: -Dfml.queryResult=confirm
while true
do
   java -Xms6G -Xmx6G -Dfml.readTimeout=180 -Duser.language=en @java9args.txt -jar lwjgl3ify-forgePatches.jar nogui
    echo "If you want to completely stop the server process now, press Ctrl+C before the time is up!"
    echo "Rebooting in:"
    for i in 12 11 10 9 8 7 6 5 4 3 2 1
    do
        echo "$i..."
        sleep 1
    done
    echo "Rebooting now!"
done
