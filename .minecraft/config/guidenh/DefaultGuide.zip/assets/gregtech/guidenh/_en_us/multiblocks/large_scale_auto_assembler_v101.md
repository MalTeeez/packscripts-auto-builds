---
item_ids:
  - gregtech:gt.blockmachines:876
bindings:
  - {type: "betterquesting", id: "AAAAAAAAAAAAAAAAAAAIBg=="}
  - {type: "betterquesting", id: "AAAAAAAAAAAAAAAAAAAKQg=="}
navigation:
  title: Large Scale Auto-Assembler v1.01
  parent: ./multiblocks_index.md
  icon: gregtech:gt.blockmachines:876
  position: -7001
---
# Large Scale Auto-Assembler v1.01
