---
item_ids:
  - gregtech:gt.blockmachines:15331
  - gregtech:gt.blockmachines:15451
bindings:
  - {type: "betterquesting", id: "AAAAAAAAAAAAAAAAAAAH2A=="}
navigation:
  title: Research Station
  parent: ./multiblocks_index.md
  icon: gregtech:gt.blockmachines:15331
  position: -8001
---
# Research Station
