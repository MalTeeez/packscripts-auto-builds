---
navigation:
  parent: /items_blocks_index.md
  title: 陨石箱子
  icon: appliedenergistics2:tile.BlockSkyChest
categories:
- misc ingredients blocks
item_ids:
- appliedenergistics2:tile.BlockSkyChest
---

<ItemImage id="appliedenergistics2:tile.BlockSkyChest" scale="4"/>

地图上刷新的陨石地形的陨石核心有概率刷新陨石箱子，其中可能含有<ItemLink id="appliedenergistics2:item.ItemMultiMaterial:13" showIcon="left"/>、<ItemLink id="appliedenergistics2:item.ItemMultiMaterial:14" showIcon="left"/>、<ItemLink id="appliedenergistics2:item.ItemMultiMaterial:15" showIcon="left"/>和<ItemLink id="appliedenergistics2:item.ItemMultiMaterial:19" showIcon="left"/>。

陨石箱子与箱子不同，在上方有固体方块阻挡时也可以打开。
