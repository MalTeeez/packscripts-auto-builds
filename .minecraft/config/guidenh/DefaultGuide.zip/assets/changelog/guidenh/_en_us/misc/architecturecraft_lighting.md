---
navigation:
  title: Improved ArchitectureCraft Lighting
  parent: misc.md
  icon: ArchitectureCraft:sawbench
categories:
    - Miscellaneous Changes
author: Skorched
date: 2026-05-22
---
# Improved ArchitectureCraft Lighting
Are you one of the many players that love using <Color id="BLUE">ArchitectureCraft</Color> for building, but hate the lighting effects on the angles it creates! Well cry no more!
By changing the way the internal calculations work, the transitions between these blocks are now more seamless than ever! Just look:
<FloatingImage src="../assets/misc/lighting.png" displayWidth="256" wrap="square">
  <ImageAnnotation>
    Before and After for some specific cases
</ImageAnnotation>
</FloatingImage>
<FloatingImage src="../assets/misc/lighting_2.png" displayWidth="256" wrap="square">
  <ImageAnnotation>
    Before and After for some specific cases
</ImageAnnotation>
</FloatingImage>
<FloatingImage src="../assets/misc/lighting_3.png" displayWidth="256" wrap="square">
  <ImageAnnotation>
    Before and After for some specific cases
</ImageAnnotation>
</FloatingImage>
